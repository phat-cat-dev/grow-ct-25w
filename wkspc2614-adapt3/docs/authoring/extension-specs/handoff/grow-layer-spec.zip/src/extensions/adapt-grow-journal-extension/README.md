# adapt-grow-journal-extension

**GROW Journal (course notebook)** — one running journal for the whole course,
opened from a note-making button in Adapt's top navigation bar.

This is the *extension* form of the [`adapt-grow-journal`](../adapt-grow-journal)
component. Where the component is a lined textarea dropped into a block on one
page, this extension gives the learner a single, course-wide notebook reachable
from every page.

## How it works

- A **note-making button** (Material Symbols `edit_note`) is injected into
  `.nav__inner` through `adapt-grow-layer`'s `navMount`, so it survives Adapt's
  per-page nav re-render — the same pattern the GROW mode and page-nav buttons
  use.
- Clicking it opens a **non-blocking notebook panel** in the shared
  `growLayer.overlay()` stage (right-docked on desktop, a bottom sheet on
  mobile). `Escape` or the close button dismisses it; focus returns to the
  button.
- The notebook is **one markdown document** for the course:

  ```
  # My course
  ## Course opening
  ## Lesson 01
  ## Lesson 02
  ```

  It is seeded on first use from `config._growJournalExtension._template`, or —
  if none is authored — auto-generated as `# <course title>` followed by one
  `## <page title>` per page.
- Opening the panel on a page **scrolls to that page's heading** and drops the
  caret into its section. A page maps to a heading via its own
  `_growJournalExtension._heading`, else its page title. Any mapped heading
  missing from the notebook is appended, so every page always has a home.

## Persistence

Text is written through `offlineStorage` into `suspend_data` (not
`cmi.interactions`) under one global key (`gjx:course`), so it is the same
notebook everywhere and is restored on `adapt:start`. A `localStorage` mirror
lets the notebook survive reloads in a dev harness with no LMS connected.

## Authoring

Enable and configure in `config.json`:

```json
"_growJournalExtension": {
  "_isEnabled": true,
  "_template": "# My course\n## Course opening\n## Lesson 01\n## Lesson 02"
}
```

Map a page to a heading in its `contentObjects.json` entry:

```json
"_growJournalExtension": { "_heading": "Lesson 01" }
```

See [`example.json`](example.json) and [`properties.schema`](properties.schema)
for the full option set (labels, placeholder, status strings).

## Dependencies

- [`adapt-grow-layer`](../adapt-grow-layer) — the host region / overlay stage
  and the `navMount` nav-chrome lifecycle.
- The GROW theme supplies the ruled-paper tokens and the self-hosted
  **Material Symbols Outlined** icon font.

## License

GPL-3.0
