import Adapt from 'core/js/adapt';

/**
 * GROW Layer
 * ==========================================================================
 * One persistent host region the GROW "end-game" tools (the ones that ship in
 * the exported course) mount onto, so they share a single managed surface
 * instead of each spinning up its own ad-hoc fixed layer.
 *
 * Originally this was `adapt-grow-layer` in the source build — the region that
 * carried the theme-manager dock, the mode switcher and the menu decoration.
 * That extension was dropped from the GROW-CT import (the runtime studio isn't
 * shipped). This is the lean host rebuilt from it: no studio, just the plumbing
 * the shipping tools need.
 *
 *   #grow-layer                       the region (appended to <body> ONCE, so it
 *   ├─ .grow-layer__overlay           survives Adapt's per-page re-render)
 *   │                                 a fixed, full-viewport, click-through STAGE;
 *   │                                 overlay tools (pagenotes) append here, giving
 *   │                                 every GROW overlay one stacking context.
 *   └─ .grow-layer__dock              a fixed BOTTOM zone for toolbar tools; it
 *                                     reserves --grow-dock-h (html.grow-has-dock)
 *                                     so page content can scroll clear of it.
 *
 * Nav-bar chrome (the mode button, page prev/next) must physically live in core's
 * .nav__inner, which Adapt re-renders on every page. So the layer doesn't contain
 * those — it COORDINATES them: navMount() registers an idempotent injector that
 * the layer re-runs on every pageView/menuView ready. Each tool keeps its own
 * build/placement logic; the layer just owns the lifecycle they used to duplicate.
 *
 * API (default export, and Adapt.growLayer):
 *   getRoot()            -> HTMLElement  the #grow-layer region (lazy)
 *   overlay()            -> HTMLElement  the shared overlay stage (lazy)
 *   dock()               -> HTMLElement  the bottom dock zone (lazy; reserves space)
 *   navMount(id, inject) -> unmount fn   inject:(nav)=>void, run on every nav render;
 *                                        must be idempotent (guard its own marker).
 */
class GrowLayer {

  constructor() {
    this._root = null;
    this._overlay = null;
    this._dock = null;
    this._navInjectors = [];
    this._runNav = this._runNav.bind(this);
    // Build the region as soon as the app DOM exists, and keep nav chrome in
    // place across every page/menu view.
    Adapt.on('app:dataReady', () => this.getRoot());
    Adapt.on('pageView:ready menuView:ready', this._runNav);
  }

  /** The #grow-layer region, created once on <body>. */
  getRoot() {
    if (this._root && this._root.isConnected) return this._root;
    let root = document.getElementById('grow-layer');
    if (!root) {
      root = document.createElement('div');
      root.id = 'grow-layer';
      root.className = 'grow-layer';
      root.setAttribute('role', 'region');
      root.setAttribute('aria-label', 'GROW layer');
      (document.body || document.documentElement).appendChild(root);
    }
    this._root = root;
    return root;
  }

  /** Shared, click-through, full-viewport stage for overlays to append into. */
  overlay() {
    if (this._overlay && this._overlay.isConnected) return this._overlay;
    const stage = document.createElement('div');
    stage.className = 'grow-layer__overlay';
    this.getRoot().appendChild(stage);
    this._overlay = stage;
    return stage;
  }

  /** Fixed bottom dock zone; reserves --grow-dock-h so content clears it. */
  dock() {
    if (this._dock && this._dock.isConnected) return this._dock;
    const dock = document.createElement('div');
    dock.className = 'grow-layer__dock';
    dock.setAttribute('role', 'group');
    dock.setAttribute('aria-label', 'GROW tools');
    this.getRoot().appendChild(dock);
    document.documentElement.classList.add('grow-has-dock');
    this._dock = dock;
    return dock;
  }

  /**
   * Register nav-bar chrome maintained across page views.
   * @param {string} id        unique key; a second register with the same id replaces.
   * @param {(nav:HTMLElement)=>void} inject  idempotent: build+place the node(s), but
   *        return early if the marker is already in `nav` (it is re-run every page).
   * @returns {() => void} unmount — stops future re-injection (does not remove the node).
   */
  navMount(id, inject) {
    this._navInjectors = this._navInjectors.filter(n => n.id !== id);
    this._navInjectors.push({ id, inject });
    this._runNav();
    return () => { this._navInjectors = this._navInjectors.filter(n => n.id !== id); };
  }

  _runNav() {
    const nav = document.querySelector('.nav__inner');
    if (!nav) return;
    for (const { inject } of this._navInjectors) {
      try { inject(nav); } catch (e) { /* one tool must not break the others */ }
    }
  }

}

const growLayer = new GrowLayer();
// Non-module access for tools that reach it off the Adapt global.
Adapt.growLayer = growLayer;

export default growLayer;
