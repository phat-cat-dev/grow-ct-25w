# adapt-grow-studio

The **GROW Theme Studio** as a design-time drawer, mounted on the GROW layer.

A launch button (`tune`) is injected into Adapt's top navigation bar; clicking it
slides in a fixed drawer containing the tabbed studio — **Colour, Typography,
Elements, Page layout** (Spacing and Icons are placeholders) — which emits GROW
theme tokens + page JSON and exports a theme-pack.

## How it mounts

- The launch button is registered through **`adapt-grow-layer`**'s `navMount`
  (idempotent, re-run on every page/menu view) so it lives with the other GROW
  management chrome and survives Adapt's per-page re-render.
- The drawer is appended **once to `#grow-layer`** (`growLayer.getRoot()`); the
  studio shell (`js/studio/*`) is mounted into it lazily on first open.
- **Fallback:** if `adapt-grow-layer` is absent, the extension floats its own
  launch button and appends the drawer to `<body>` — the same approach, its own
  layer.

## Design-time only

Active by default so it appears in the component harness / comps. Disable it per
course:

```json
"_growStudio": { "_isEnabled": false }
```

## Internals

- `js/adapt-grow-studio.js` — the extension entry (`GrowStudio`): nav button +
  drawer + lazy `mountStudio`.
- `js/studio/` — the pure-DOM studio shell, copied from `inbox/theme-studio`
  (shell, tab-host, colour/typography/elements managers, page-builder). No Adapt
  dependency; it manipulates the DOM directly.
- `less/` — the drawer chrome (`grow-studio.less`) plus the studio's own
  component CSS (`_studio-*.less`). The studio CSS had its `:root` token
  fallbacks **stripped**, so it inherits the live GROW theme tokens instead of
  redefining them — move the theme hue and the studio reskins with it.

> LESS note: the imported studio CSS uses CSS `min()` with mixed-unit literals
> (`min(100%, 10rem)`), which collides with LESS's built-in `min()`. Those are
> escaped as `~"min(…)"`. `minmax()` passes through unharmed.
