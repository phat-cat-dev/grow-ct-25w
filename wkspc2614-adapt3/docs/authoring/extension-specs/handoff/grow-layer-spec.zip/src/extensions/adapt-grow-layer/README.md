# adapt-grow-layer — GROW Layer

A single persistent host region (`#grow-layer`) that the GROW **end-game / exported**
tools mount onto, so they share one managed surface instead of each creating its own
ad-hoc fixed layer.

It is the lean rebuild of the original `adapt-grow-layer` from the source build — the
region that carried the theme-manager dock, the mode switcher and the menu decoration.
That extension was dropped from the GROW-CT import because the **runtime theme/typography
studio isn't shipped** (chosen values are baked into `_grow-tokens.less`). This host keeps
only the plumbing the shipping tools need; **the studio is deliberately out of scope** and
will get its own layer.

## What it gives you

```
#grow-layer                  the region, appended to <body> ONCE (survives page re-render)
├─ .grow-layer__overlay      fixed, full-viewport, click-through stage — overlay tools append here
└─ .grow-layer__dock         fixed bottom zone for toolbar tools — reserves --grow-dock-h
```

Nav-bar chrome (mode button, page prev/next) has to live in core's `.nav__inner`, which
Adapt re-renders every page — so the layer **coordinates** it rather than containing it.

## API

Imported by other plugins as a shared singleton, and exposed on `Adapt.growLayer`:

```js
import growLayer from 'extensions/adapt-grow-layer/js/adapt-grow-layer';

growLayer.getRoot();              // -> #grow-layer element (lazy)
growLayer.overlay();              // -> the shared overlay stage (lazy)
growLayer.dock();                 // -> the bottom dock zone (lazy; reserves space)

// Register nav chrome that must survive Adapt's per-page nav re-render.
// `inject(nav)` is run on every pageView/menuView ready and MUST be idempotent
// (guard your own marker / `nav.querySelector(...)`). Returns an unmount fn.
const off = growLayer.navMount('my-tool', (nav) => {
  if (nav.querySelector('[data-grow-nav="my-tool"]')) return;
  const btn = document.createElement('button');
  btn.setAttribute('data-grow-nav', 'my-tool');
  nav.appendChild(btn);
});
```

## Consumers

- **adapt-grow-pagenotes** — appends its overlay into `growLayer.overlay()`.
- **adapt-grow-pagenav** — registers its prev/next injection via `navMount('pagenav', …)`.
- **adapt-grow-mode** — registers its mode button via `navMount('mode', …)`.

Dependency-free; no config beyond `_growLayer._isEnabled` (default true). Runs on
`app:dataReady`.
