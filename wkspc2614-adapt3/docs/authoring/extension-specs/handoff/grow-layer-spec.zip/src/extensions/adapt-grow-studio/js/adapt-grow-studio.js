import Adapt from 'core/js/adapt';
import growLayer from 'extensions/adapt-grow-layer/js/adapt-grow-layer';
import { mountStudio } from './studio/studio-shell.js';

/**
 * GROW Studio
 * ==========================================================================
 * Mounts the GROW Theme Studio (the pure-DOM shell under js/studio/*) as a
 * design-time drawer hosted on the GROW layer.
 *
 *   • A launch button is injected into the top nav via growLayer.navMount
 *     (idempotent, re-run on every page/menu view), so it survives Adapt's
 *     per-page re-render and lives with the other GROW management chrome.
 *   • The studio itself is a fixed drawer appended ONCE to #grow-layer
 *     (growLayer.getRoot), mounted lazily the first time it is opened, and
 *     toggled open/closed. It is self-contained: its own stacking context and
 *     pointer-events, independent of the click-through overlay stage.
 *   • If the grow-layer extension is absent, it falls back to its own fixed
 *     launch button and appends the drawer to <body> — "generate its own
 *     studio layer" using the same approach.
 *
 * This is a DESIGN-TIME tool. It is active by default (so it shows in the
 * component harness / comps); authors disable it per course with
 * config.json → "_growStudio": { "_isEnabled": false }.
 */
class GrowStudio {

  constructor() {
    this._panel = null;
    this._body = null;
    this._open = false;
    this._mounted = false;
    this._inject = this._inject.bind(this);
    this.toggle = this.toggle.bind(this);

    Adapt.once('app:dataReady', () => {
      const cfg = Adapt.config && Adapt.config.get && Adapt.config.get('_growStudio');
      if (cfg && cfg._isEnabled === false) return;
      if (growLayer && typeof growLayer.navMount === 'function') {
        growLayer.navMount('grow-studio', this._inject);
      } else {
        this._fallbackButton();
      }
    });
  }

  /** Idempotent nav-bar injector (re-run every page by growLayer). */
  _inject(nav) {
    if (nav.querySelector('.grow-studio-launch')) return;
    nav.appendChild(this._launchButton());
  }

  _launchButton() {
    const b = document.createElement('button');
    b.className = 'grow-studio-launch nav__btn';
    b.type = 'button';
    b.setAttribute('aria-label', 'GROW Theme Studio');
    b.setAttribute('aria-haspopup', 'dialog');
    b.innerHTML = '<span class="material-symbols-outlined" aria-hidden="true">tune</span>';
    b.addEventListener('click', this.toggle);
    return b;
  }

  /** No grow-layer present: float our own launch button bottom-right. */
  _fallbackButton() {
    const b = this._launchButton();
    b.classList.add('grow-studio-launch--floating');
    (document.body || document.documentElement).appendChild(b);
  }

  /** Build the drawer once; mount the studio shell into it lazily. */
  _ensurePanel() {
    if (this._panel && this._panel.isConnected) return this._panel;

    const panel = document.createElement('div');
    panel.className = 'grow-studio-panel';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-label', 'GROW Theme Studio');
    panel.setAttribute('aria-modal', 'false');

    const bar = document.createElement('div');
    bar.className = 'grow-studio-bar';
    const title = document.createElement('div');
    title.className = 'grow-studio-title';
    title.textContent = 'GROW Theme Studio';
    const close = document.createElement('button');
    close.className = 'grow-studio-close';
    close.type = 'button';
    close.setAttribute('aria-label', 'Close studio');
    close.innerHTML = '<span class="material-symbols-outlined" aria-hidden="true">close</span>';
    close.addEventListener('click', () => this.close());
    bar.append(title, close);

    const body = document.createElement('div');
    body.className = 'grow-studio-body';

    panel.append(bar, body);

    const host = (growLayer && typeof growLayer.getRoot === 'function')
      ? growLayer.getRoot()
      : (document.body || document.documentElement);
    host.appendChild(panel);

    this._panel = panel;
    this._body = body;
    return panel;
  }

  toggle() { this._open ? this.close() : this.open(); }

  open() {
    this._ensurePanel();
    if (!this._mounted) {
      try { mountStudio(this._body); this._mounted = true; }
      catch (e) { /* a studio section failing must not break the course */ }
    }
    this._panel.classList.add('is-open');
    document.documentElement.classList.add('grow-studio-active');
    this._open = true;
  }

  close() {
    if (this._panel) this._panel.classList.remove('is-open');
    document.documentElement.classList.remove('grow-studio-active');
    this._open = false;
  }

}

const growStudio = new GrowStudio();
Adapt.growStudio = growStudio;

export default growStudio;
