import Adapt from 'core/js/adapt';
import growLayer from 'extensions/adapt-grow-layer/js/adapt-grow-layer';

/**
 * GROW Mode
 * --------------------------------------------------------------------------
 * A single "Display mode" button injected into Adapt's top navigation bar
 * (`.nav__inner`). It opens a popup menu that lets the learner:
 *
 *   - switch THEME         → light / dark / contrast  (sets `data-theme` on <html>)
 *   - toggle ANIMATIONS    → on / off                 (sets `data-motion="off"`)
 *   - toggle BACKGROUNDS   → on / off                 (sets `data-bg="off"`)
 *
 * All three choices persist in localStorage and are restored on load, so the
 * display mode follows the learner across pages and sessions. The actual
 * visual styling for each mode (the light/dark/contrast palettes, the reduced-
 * motion rules, the notebook background textures) lives in the GROW theme —
 * this extension only toggles the attributes/classes the theme keys off.
 *
 * On every page / menu view it also applies ONE "notebook" background class to
 * <html> (nb-lined / nb-handwriting / nb-legalpad / nb-quad / nb-hairlines /
 * nb-microgrid). The class is chosen from, in order: the model's `_growBg`, a
 * matching entry in the model's `_classes`, or a weighted random pick cached
 * per page id in sessionStorage. Backgrounds are suppressed in the contrast
 * theme or when the Backgrounds toggle is off.
 *
 * The top nav template is owned by adapt-contrib-navigation (not overridable
 * from the theme), so the button is injected into `.nav__inner` at runtime.
 *
 * Reconstructed from the compiled course bundle (adapt.min.js, class GrowMode).
 */

const KEY_THEME = 'grow-mode-theme';
const KEY_MOTION = 'grow-mode-motion';
const KEY_BG = 'grow-mode-bg';

const MODES = [
  { id: 'light', label: 'Light', icon: 'light_mode' },
  { id: 'dark', label: 'Dark', icon: 'dark_mode' },
  { id: 'contrast', label: 'Contrast', icon: 'contrast' }
];

// Notebook background classes and their relative weights for the random pick.
const NB_WEIGHTS = [
  ['nb-lined', 3],
  ['nb-handwriting', 2],
  ['nb-legalpad', 2],
  ['nb-quad', 1.5],
  ['nb-hairlines', 1],
  ['nb-microgrid', 1]
];
const NB_ALL = NB_WEIGHTS.map(w => w[0]);

class GrowMode {

  constructor() {
    // Authoring switch: config.json → "_growMode": { "_isEnabled": false } to disable.
    if (Adapt.config && Adapt.config.get('_growMode') && Adapt.config.get('_growMode')._isEnabled === false) return;

    this.mount = this.mount.bind(this);
    this._lastModel = null;
    this.restore();
    // The mode button is nav chrome: register it with the GROW layer, which
    // re-runs this idempotent injection on every nav render. (The button still
    // physically lives in core's .nav__inner — mount() places it there.)
    growLayer.navMount('mode', this.mount);
    Adapt.on('pageView:ready menuView:ready', view => {
      this._lastModel = (view && view.model) || null;
      this.setPageBg(this._lastModel);
    });
  }

  // Re-apply the persisted theme / motion / background choices to <html>.
  restore() {
    try {
      const t = localStorage.getItem(KEY_THEME);
      if (t) document.documentElement.setAttribute('data-theme', t);
      if (localStorage.getItem(KEY_MOTION) === 'off') document.documentElement.setAttribute('data-motion', 'off');
      if (localStorage.getItem(KEY_BG) === 'off') document.documentElement.setAttribute('data-bg', 'off');
    } catch (e) {}
  }

  // Build and inject the button + menu into the top nav (once).
  mount() {
    const nav = document.querySelector('.nav__inner');
    if (!nav || nav.querySelector('.grow-mode')) return;

    const wrap = document.createElement('div');
    wrap.className = 'grow-mode';
    wrap.setAttribute('data-order', '95');
    wrap.innerHTML = `
      <button type="button" class="btn-icon nav__btn grow-mode__toggle" aria-haspopup="true" aria-expanded="false" aria-label="Display mode" title="Mode">
        <span class="grow-mode__icon" aria-hidden="true">tune</span>
      </button>
      <div class="grow-mode__panel" role="menu" hidden>
        ${MODES.map(m => `<button type="button" class="grow-mode__opt" role="menuitemradio" data-mode="${m.id}"><span class="grow-mode__icon" aria-hidden="true">${m.icon}</span><span>${m.label}</span></button>`).join('')}
        <button type="button" class="grow-mode__opt grow-mode__motion" role="menuitemcheckbox"><span class="grow-mode__icon" aria-hidden="true">animation</span><span>Animations</span></button>
        <button type="button" class="grow-mode__opt grow-mode__bg" role="menuitemcheckbox"><span class="grow-mode__icon" aria-hidden="true">wallpaper</span><span>Backgrounds</span></button>
      </div>`;
    nav.appendChild(wrap);

    const toggle = wrap.querySelector('.grow-mode__toggle');
    const panel = wrap.querySelector('.grow-mode__panel');
    const setOpen = open => {
      panel.toggleAttribute('hidden', !open);
      toggle.setAttribute('aria-expanded', String(open));
    };

    toggle.addEventListener('click', () => setOpen(panel.hasAttribute('hidden')));
    wrap.querySelectorAll('.grow-mode__opt[data-mode]').forEach(btn => btn.addEventListener('click', () => this.setTheme(btn.dataset.mode)));
    wrap.querySelector('.grow-mode__motion').addEventListener('click', () => this.toggleMotion());
    wrap.querySelector('.grow-mode__bg').addEventListener('click', () => this.toggleBg());
    document.addEventListener('click', e => {
      if (!wrap.contains(e.target)) setOpen(false);
    });

    this.reflect();
  }

  setTheme(id) {
    document.documentElement.setAttribute('data-theme', id);
    try { localStorage.setItem(KEY_THEME, id); } catch (e) {}
    this.setPageBg(this._lastModel);
    this.reflect();
  }

  toggleMotion() {
    const off = document.documentElement.getAttribute('data-motion') === 'off';
    if (off) document.documentElement.removeAttribute('data-motion');
    else document.documentElement.setAttribute('data-motion', 'off');
    try { localStorage.setItem(KEY_MOTION, off ? 'on' : 'off'); } catch (e) {}
    this.reflect();
  }

  toggleBg() {
    const html = document.documentElement;
    const off = html.getAttribute('data-bg') === 'off';
    if (off) html.removeAttribute('data-bg');
    else html.setAttribute('data-bg', 'off');
    try { localStorage.setItem(KEY_BG, off ? 'on' : 'off'); } catch (e) {}
    this.setPageBg(this._lastModel);
    this.reflect();
  }

  // Weighted random notebook-background pick.
  pickNb() {
    const tot = NB_WEIGHTS.reduce((a, [, w]) => a + w, 0);
    let r = Math.random() * tot;
    for (const [k, w] of NB_WEIGHTS) {
      if ((r -= w) < 0) return k;
    }
    return NB_ALL[0];
  }

  // Resolve the notebook-background class for a given view model.
  nbFor(model) {
    if (model) {
      const pref = model.get('_growBg');
      if (NB_ALL.includes(pref)) return pref;
      const inClasses = (model.get('_classes') || '').split(/\s+/).find(c => NB_ALL.includes(c));
      if (inClasses) return inClasses;
    }
    const id = (model && model.get('_id')) || 'page';
    try {
      const map = JSON.parse(sessionStorage.getItem('grow-nb-map') || '{}');
      if (!map[id]) {
        map[id] = this.pickNb();
        sessionStorage.setItem('grow-nb-map', JSON.stringify(map));
      }
      return map[id];
    } catch (e) {
      return this.pickNb();
    }
  }

  // Apply the notebook background class for the current page, unless suppressed.
  setPageBg(model) {
    const html = document.documentElement;
    NB_ALL.forEach(c => html.classList.remove(c));
    const off = html.getAttribute('data-bg') === 'off' || html.getAttribute('data-theme') === 'contrast';
    if (off) return;
    html.classList.add(this.nbFor(model));
  }

  // Sync every menu's aria-checked / is-off state to the current mode.
  reflect() {
    const theme = document.documentElement.getAttribute('data-theme') || 'light';
    const motionOff = document.documentElement.getAttribute('data-motion') === 'off';
    const bgOff = document.documentElement.getAttribute('data-bg') === 'off';
    document.querySelectorAll('.grow-mode').forEach(wrap => {
      wrap.querySelectorAll('.grow-mode__opt[data-mode]').forEach(b => b.setAttribute('aria-checked', String(b.dataset.mode === theme)));
      const mb = wrap.querySelector('.grow-mode__motion');
      if (mb) {
        mb.setAttribute('aria-checked', String(!motionOff));
        mb.classList.toggle('is-off', motionOff);
      }
      const bb = wrap.querySelector('.grow-mode__bg');
      if (bb) {
        bb.setAttribute('aria-checked', String(!bgOff));
        bb.classList.toggle('is-off', bgOff);
      }
    });
  }

}

export default new GrowMode();
