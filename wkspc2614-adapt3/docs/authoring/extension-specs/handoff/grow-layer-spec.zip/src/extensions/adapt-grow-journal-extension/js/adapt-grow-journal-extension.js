import Adapt from 'core/js/adapt';
import offlineStorage from 'core/js/offlineStorage';
import logging from 'core/js/logging';
import growLayer from 'extensions/adapt-grow-layer/js/adapt-grow-layer';

/**
 * GROW Journal (course notebook)
 * ==========================================================================
 * ONE running journal for the whole course, reached from a note-making button
 * in Adapt's top navigation bar. It is the extension form of the growJournal
 * component: instead of a textarea dropped into a block on one page, it is a
 * single course-wide notebook available on every page.
 *
 * The notebook is a single markdown-ish document:
 *
 *     # <course title>
 *     ## Course opening
 *     ## Lesson 01
 *     ## Lesson 02
 *
 * It is SEEDED from, in order:
 *   1. config._growJournalExtension._template   (an authored markdown string), or
 *   2. an auto-generated template — "# <course title>" followed by one
 *      "## <page heading>" per page — when no template is authored.
 *
 * Opening the panel on a page scrolls to THAT page's heading (in whichever view
 * is active) and, in code view, drops the caret into its section. A page is
 * mapped to a heading by, in order: its own `_growJournalExtension._heading`,
 * else its displayTitle/title. Any mapped heading missing from the notebook is
 * appended, so every page has a home.
 *
 * Panel chrome the learner controls (all persisted in localStorage):
 *   - VIEW  : code (raw markdown, editable) ⇄ preview (rendered, read-only)
 *   - DOCK  : left / right / top / bottom edge, or `float` — a small card on the
 *             left of the page that expands down into a scrollable notebook.
 *
 * Persistence of the TEXT mirrors the growJournal component: written through
 * offlineStorage into suspend_data (NOT cmi.interactions) under one global key,
 * with a localStorage mirror so it survives reloads in a dev harness with no LMS.
 *
 * Nav chrome lives in core's .nav__inner, which Adapt re-renders every page, so
 * the button is (re)injected through growLayer.navMount. The panel mounts into
 * the shared growLayer.overlay() stage so every GROW overlay shares one context.
 *
 * Authoring switch: config.json → "_growJournalExtension": { "_isEnabled": false }.
 */

const LOG_PREFIX = '[grow-journal-extension]';
const STORAGE_KEY = 'gjx:course';
const LS_KEY = 'gjx:course';
const LS_VIEW = 'gjx:view';
const LS_DOCK = 'gjx:dock';
const LS_COLLAPSED = 'gjx:collapsed';
const LS_FLOATRECT = 'gjx:floatrect';
const LS_INTRO = 'gjx:introSeen';   // one-time flag: show instructions on first open

// Default "how to use your notes" instructions, shown from the top toolbar's
// help icon and auto-opened the first time the notebook is opened in a course.
// Authors can override the whole thing with config._growJournalExtension._instructions.
// (Built from an array so the inline `code` backticks don't clash with the
// JS template-literal delimiter.)
const INSTRUCTIONS_MD = [
  '## How to use your notes',
  'This page is your journal. Write ideas, questions and reflections as you go.',
  '',
  '- Moodle saves your notes, so you can leave and come back',
  '- Nobody else sees them',
  '- Download them as a PDF from the menu page at any time',
  '',
  '## Markdown in a minute',
  'Markdown is a simple way to format notes. Press the view icon above to see how this page looks when displayed.',
  '',
  '### Headings',
  'Start a line with `#` to make a heading. More hashes make a smaller heading.',
  '',
  '- `#` is the course title',
  '- `##` is each page or lesson',
  '- `###` and below are yours to add',
  '',
  '### Lists',
  '- Start a line with `-` for bullet points',
  '1. Start a line with `1.` for a numbered list',
  '',
  '### Chunking',
  'Short headings with a few points under each help you remember more than long paragraphs.',
  '',
  '### Just write',
  "Don't worry about spelling or structure. You can tidy up later. It's your learning."
].join('\n');

// The injected guide is bracketed by these HTML-comment markers so it can be
// found and removed reliably, is invisible in the rendered preview, and is
// never written to storage. this._text stays the learner's pristine notes.
const INSTR_START = '<!--grow-journal-instructions-->';
const INSTR_END = '<!--/grow-journal-instructions-->';
const escapeRegExp = s => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// Float-card size bounds (kept in step with the CSS min/max on [data-dock='float']).
const FLOAT_MIN_W = 240;
const FLOAT_MIN_H = 132;

const DEFAULTS = {
  openButtonLabel: 'Course notebook',
  panelTitle: 'My course notebook',
  closeButtonLabel: 'Close notebook',
  helpButtonLabel: 'How to use your notes',
  closeInstructionsLabel: 'Close instructions',
  placeholder: 'Write your notes here…',
  statusSaved: 'Saved',
  statusUnsaved: 'Saving…',
  statusFailed: 'Could not save'
};

const DOCKS = [
  { id: 'left', icon: 'arrow_back', label: 'Dock left' },
  { id: 'top', icon: 'arrow_upward', label: 'Dock top' },
  { id: 'bottom', icon: 'arrow_downward', label: 'Dock bottom' },
  { id: 'right', icon: 'arrow_forward', label: 'Dock right' },
  { id: 'float', icon: 'filter_none', label: 'Float as a card (left)' }
];
const DOCK_IDS = DOCKS.map(d => d.id);

const escapeHtml = s => String(s ?? '').replace(/[&<>"']/g, c => (
  { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
));

// Markdown/HTML-free, case-insensitive key for matching a page title to a heading.
const normalise = s => String(s ?? '')
  .replace(/<[^>]*>/g, '')
  .replace(/\s+/g, ' ')
  .trim()
  .toLowerCase();

const isHeadingLine = line => /^#{1,6}\s+\S/.test(line.trim());
const headingText = line => line.trim().replace(/^#{1,6}\s+/, '').trim();

/**
 * Small, dependency-free markdown → HTML renderer for the preview. Handles the
 * subset a notebook needs: ATX headings, unordered/ordered lists, blockquotes,
 * paragraphs, and inline code / bold / italic / links. Everything is HTML-escaped
 * first, so learner text can never inject markup; links are forced to safe http(s)
 * and open in a new tab.
 */
function renderMarkdown(src) {
  const escHtml = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const inline = s => escHtml(s)
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/\*([^*\n]+)\*/g, '<em>$1</em>')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');

  const lines = String(src ?? '').replace(/\r\n/g, '\n').split('\n');
  const out = [];
  let list = null;
  let para = [];
  const closeList = () => { if (list) { out.push(`</${list}>`); list = null; } };
  const closePara = () => { if (para.length) { out.push(`<p>${inline(para.join(' '))}</p>`); para = []; } };

  for (const raw of lines) {
    const line = raw.replace(/\s+$/, '');
    if (/^<!--[\s\S]*?-->$/.test(line.trim())) { closePara(); closeList(); continue; } // drop HTML comments (instruction markers)
    const h = /^(#{1,6})\s+(.*)$/.exec(line);
    const uli = /^[-*]\s+(.*)$/.exec(line);
    const oli = /^(\d+)\.\s+(.*)$/.exec(line);
    const bq = /^>\s?(.*)$/.exec(line);
    if (h) {
      closePara(); closeList();
      out.push(`<h${h[1].length} class="gjx-md__h">${inline(h[2])}</h${h[1].length}>`);
    } else if (uli) {
      closePara();
      if (list !== 'ul') { closeList(); out.push('<ul>'); list = 'ul'; }
      out.push(`<li>${inline(uli[1])}</li>`);
    } else if (oli) {
      closePara();
      if (list !== 'ol') { closeList(); out.push('<ol>'); list = 'ol'; }
      out.push(`<li>${inline(oli[2])}</li>`);
    } else if (bq) {
      closePara(); closeList();
      out.push(`<blockquote>${inline(bq[1])}</blockquote>`);
    } else if (line.trim() === '') {
      closePara(); closeList();
    } else {
      closeList();
      para.push(line.trim());
    }
  }
  closePara(); closeList();
  return out.join('\n');
}

class GrowJournalExtension {

  constructor() {
    this._text = '';
    this._loaded = false;
    this._panel = null;
    this._textarea = null;
    this._preview = null;
    this._status = null;
    this._lastModel = null;
    this._returnFocusTo = null;

    // UI state (restored lazily from localStorage on first open).
    this._view = 'code';
    this._dock = 'right';
    this._collapsed = false;
    this._instructions = false; // instructions layer visible (never persisted)
    this._stateLoaded = false;

    // Float-card drag / resize.
    this._head = null;
    this._drag = null;
    this._floatRect = null;
    this._resizeObserver = null;
    this._applyingRect = false; // guards the ResizeObserver during programmatic sizing

    this.mount = this.mount.bind(this);
    this.toggle = this.toggle.bind(this);
    this._onKey = this._onKey.bind(this);
    this._onInput = this._onInput.bind(this);
    this._onDragStart = this._onDragStart.bind(this);
    this._onDragMove = this._onDragMove.bind(this);
    this._onDragEnd = this._onDragEnd.bind(this);

    Adapt.once('app:dataReady', () => {
      if (!this.isEnabled) return;
      this._debouncedSave = _.debounce(this._save.bind(this), 1200, { maxWait: 8000 });
      growLayer.navMount('journal', this.mount);
      Adapt.on('pageView:ready menuView:ready', view => { this._lastModel = (view && view.model) || null; });
      Adapt.once('adapt:start', () => this._load());
    });
  }

  get config() {
    // Config-level plugin settings live on Adapt.config (config.json), the same
    // place grow-mode / grow-pagenav read theirs — NOT on Adapt.course.
    return (Adapt.config && Adapt.config.get('_growJournalExtension')) || {};
  }

  get isEnabled() {
    return this.config._isEnabled !== false;
  }

  get labels() {
    return { ...DEFAULTS, ...(this.config._labels || {}) };
  }

  get instructionsMarkdown() {
    const authored = this.config._instructions;
    if (typeof authored === 'string' && authored.trim()) return authored.replace(/\r\n/g, '\n');
    return INSTRUCTIONS_MD;
  }

  _loadState() {
    if (this._stateLoaded) return;
    try {
      const v = window.localStorage.getItem(LS_VIEW);
      if (v === 'code' || v === 'preview') this._view = v;
      const d = window.localStorage.getItem(LS_DOCK);
      if (DOCK_IDS.includes(d)) this._dock = d;
      this._collapsed = window.localStorage.getItem(LS_COLLAPSED) === '1';
    } catch (e) { /* ignore */ }
    this._stateLoaded = true;
  }

  // ---- notebook content ----------------------------------------------------

  _pages() {
    const cos = (Adapt.contentObjects && Adapt.contentObjects.models) || [];
    return cos.filter(m => m.get('_type') === 'page');
  }

  _headingFor(model) {
    if (!model) return '';
    const own = (model.get('_growJournalExtension') || {})._heading;
    const raw = own || model.get('displayTitle') || model.get('title') || '';
    return String(raw).replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim();
  }

  _autoTemplate() {
    const course = Adapt.course;
    const courseTitle = (course && (course.get('displayTitle') || course.get('title'))) || 'Course notebook';
    const lines = [`# ${String(courseTitle).replace(/<[^>]*>/g, '').trim()}`, ''];
    for (const page of this._pages()) {
      const h = this._headingFor(page);
      if (h) lines.push(`## ${h}`, '');
    }
    return lines.join('\n');
  }

  _seedTemplate() {
    const authored = this.config._template;
    if (typeof authored === 'string' && authored.trim()) return authored.replace(/\r\n/g, '\n');
    return this._autoTemplate();
  }

  _ensureHeadings() {
    const present = new Set(
      this._text.split('\n').filter(isHeadingLine).map(l => normalise(headingText(l)))
    );
    const additions = [];
    for (const page of this._pages()) {
      const h = this._headingFor(page);
      if (h && !present.has(normalise(h))) {
        additions.push(`## ${h}`, '');
        present.add(normalise(h));
      }
    }
    if (additions.length) {
      this._text = `${this._text.replace(/\s*$/, '')}\n\n${additions.join('\n')}`.replace(/\n{3,}/g, '\n\n');
    }
  }

  // ---- persistence ---------------------------------------------------------

  _load() {
    if (this._loaded) return;
    let text = null;
    try {
      const stored = offlineStorage.get(STORAGE_KEY);
      if (stored && typeof stored === 'object' && typeof stored.t === 'string') text = stored.t;
      else if (typeof stored === 'string' && stored) text = stored;
    } catch (e) { /* offlineStorage not ready / no LMS */ }
    if (text == null) {
      try { text = window.localStorage.getItem(LS_KEY); } catch (e) { /* ignore */ }
    }
    if (text == null || text === '') text = this._seedTemplate();
    this._text = text;
    this._ensureHeadings();
    this._loaded = true;
    logging.debug(`${LOG_PREFIX} notebook loaded (${this._text.length} chars)`);
  }

  _save() {
    const payload = { v: 'journal', t: this._text };
    let ok = false;
    try { offlineStorage.set(STORAGE_KEY, payload); ok = true; } catch (e) { /* no LMS */ }
    try { window.localStorage.setItem(LS_KEY, this._text); ok = true; } catch (e) { /* ignore */ }
    this._setStatus(ok ? this.labels.statusSaved : this.labels.statusFailed, !ok);
    return ok;
  }

  // ---- nav button ----------------------------------------------------------

  mount(nav) {
    if (!nav || nav.querySelector('.grow-journal-ext')) return;
    const label = escapeHtml(this.labels.openButtonLabel);
    const wrap = document.createElement('div');
    wrap.className = 'grow-journal-ext';
    wrap.setAttribute('data-order', '94');
    wrap.innerHTML = `
      <button type="button" class="btn-icon nav__btn grow-journal-ext__toggle"
              aria-haspopup="dialog" aria-expanded="false" aria-label="${label}" title="${label}">
        <span class="grow-journal-ext__icon" aria-hidden="true">edit_note</span>
      </button>`;
    nav.appendChild(wrap);
    wrap.querySelector('.grow-journal-ext__toggle').addEventListener('click', e => {
      this._returnFocusTo = e.currentTarget;
      this.toggle();
    });
  }

  _reflectToggles(open) {
    document.querySelectorAll('.grow-journal-ext__toggle').forEach(b => b.setAttribute('aria-expanded', String(open)));
  }

  // ---- panel ---------------------------------------------------------------

  toggle() {
    if (this._panel && this._panel.isConnected) this.close();
    else this.open();
  }

  open() {
    this._load();
    this._loadState();
    const L = this.labels;

    const dockBtns = DOCKS.map(d =>
      `<button type="button" class="grow-journal-ext__dock btn-icon" data-dock="${d.id}" aria-label="${escapeHtml(d.label)}" title="${escapeHtml(d.label)}" aria-pressed="false">
         <span class="grow-journal-ext__icon" aria-hidden="true">${d.icon}</span>
       </button>`).join('');

    const panel = document.createElement('div');
    panel.className = 'grow-journal-ext__panel';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-modal', 'false');
    panel.setAttribute('aria-label', L.panelTitle);
    panel.innerHTML = `
      <div class="grow-journal-ext__head">
        <h2 class="grow-journal-ext__title">${escapeHtml(L.panelTitle)}</h2>
        <div class="grow-journal-ext__tools" role="group" aria-label="Notebook tools">
          <button type="button" class="grow-journal-ext__help btn-icon" aria-label="${escapeHtml(L.helpButtonLabel)}" title="${escapeHtml(L.helpButtonLabel)}" aria-pressed="false">
            <span class="grow-journal-ext__icon" aria-hidden="true">help</span>
          </button>
          <button type="button" class="grow-journal-ext__view btn-icon" aria-label="Preview" title="Preview">
            <span class="grow-journal-ext__icon" aria-hidden="true">visibility</span>
          </button>
          <span class="grow-journal-ext__docks" role="group" aria-label="Dock">${dockBtns}</span>
          <button type="button" class="grow-journal-ext__collapse btn-icon" aria-label="Collapse" title="Collapse" aria-expanded="true">
            <span class="grow-journal-ext__icon" aria-hidden="true">expand_less</span>
          </button>
          <button type="button" class="grow-journal-ext__close btn-icon" aria-label="${escapeHtml(L.closeButtonLabel)}" title="${escapeHtml(L.closeButtonLabel)}">
            <span class="grow-journal-ext__icon" aria-hidden="true">close</span>
          </button>
        </div>
      </div>
      <div class="grow-journal-ext__body">
        <textarea class="grow-journal-ext__textarea" placeholder="${escapeHtml(L.placeholder)}" aria-label="${escapeHtml(L.panelTitle)}" spellcheck="true"></textarea>
        <div class="grow-journal-ext__preview gjx-md" tabindex="0" aria-label="Notebook preview" hidden></div>
      </div>
      <div class="grow-journal-ext__instructions-bar" hidden>
        <button type="button" class="grow-journal-ext__instructions-close" aria-label="${escapeHtml(L.closeInstructionsLabel)}" title="${escapeHtml(L.closeInstructionsLabel)}">
          <span class="grow-journal-ext__icon" aria-hidden="true">close</span>
          <span class="grow-journal-ext__instructions-close-label">${escapeHtml(L.closeInstructionsLabel)}</span>
        </button>
      </div>
      <div class="grow-journal-ext__status" aria-live="polite">${escapeHtml(L.statusSaved)}</div>`;

    growLayer.overlay().appendChild(panel);

    this._panel = panel;
    this._textarea = panel.querySelector('.grow-journal-ext__textarea');
    this._preview = panel.querySelector('.grow-journal-ext__preview');
    this._status = panel.querySelector('.grow-journal-ext__status');
    this._textarea.value = this._displayText();

    // Wire controls.
    this._textarea.addEventListener('input', this._onInput);
    panel.querySelector('.grow-journal-ext__help').addEventListener('click', () => this.toggleInstructions());
    panel.querySelector('.grow-journal-ext__instructions-close').addEventListener('click', () => this.hideInstructions());
    panel.querySelector('.grow-journal-ext__view').addEventListener('click', () => this.setView(this._view === 'code' ? 'preview' : 'code'));
    panel.querySelector('.grow-journal-ext__collapse').addEventListener('click', () => this.toggleCollapse());
    panel.querySelector('.grow-journal-ext__close').addEventListener('click', () => this.close());
    panel.querySelectorAll('.grow-journal-ext__dock').forEach(b =>
      b.addEventListener('click', () => this.setDock(b.dataset.dock)));
    document.addEventListener('keydown', this._onKey, true);

    // Float-card drag (from the header) + resize persistence.
    this._head = panel.querySelector('.grow-journal-ext__head');
    this._head.addEventListener('pointerdown', this._onDragStart);
    if (typeof ResizeObserver !== 'undefined') {
      this._resizeObserver = new ResizeObserver(() => this._onResized());
      this._resizeObserver.observe(panel);
    }

    // Apply persisted state, then reveal.
    this._instructions = false;
    this._applyDock();
    this._applyView();
    this._reflectToggles(true);
    this._scrollToHeading(this._headingFor(this._lastModel));

    // First time the notebook is opened in this course, lead with the
    // instructions (one-time; the learner can reopen them from the help icon).
    let seenIntro = true;
    try { seenIntro = window.localStorage.getItem(LS_INTRO) === '1'; } catch (e) { /* ignore */ }
    if (!seenIntro) {
      this.showInstructions();
      try { window.localStorage.setItem(LS_INTRO, '1'); } catch (e) { /* ignore */ }
    }
  }

  close() {
    if (!this._panel) return;
    if (this._debouncedSave) this._debouncedSave.flush?.();
    this._save();
    document.removeEventListener('keydown', this._onKey, true);
    this._endDrag();
    this._resizeObserver?.disconnect();
    this._resizeObserver = null;
    this._panel.remove();
    this._panel = null;
    this._textarea = null;
    this._preview = null;
    this._status = null;
    this._head = null;
    this._instructions = false;
    this._reflectToggles(false);
    this._returnFocusTo?.focus?.();
  }

  _onKey(e) {
    if (e.key === 'Escape' && this._panel) { e.preventDefault(); this.close(); }
  }

  _onInput() {
    const shown = this._textarea.value;
    // While the guide is injected, persist only the pristine notes around it.
    this._text = this._instructions ? this._stripInstructions(shown) : shown;
    this._setStatus(this.labels.statusUnsaved, false);
    this._debouncedSave();
  }

  _setStatus(text, isError) {
    if (!this._status) return;
    this._status.textContent = text;
    this._status.classList.toggle('is-failed', Boolean(isError));
  }

  // ---- view (code ⇄ preview) ----------------------------------------------

  setView(view) {
    this._view = (view === 'preview') ? 'preview' : 'code';
    try { window.localStorage.setItem(LS_VIEW, this._view); } catch (e) { /* ignore */ }
    this._applyView();
    this._scrollToHeading(this._headingFor(this._lastModel));
  }

  _applyView() {
    if (!this._panel) return;
    const preview = this._view === 'preview';
    this._panel.dataset.view = this._view;
    if (preview) this._preview.innerHTML = renderMarkdown(this._displayText());
    else this._textarea.value = this._displayText();
    this._preview.hidden = !preview;
    this._textarea.hidden = preview;
    const btn = this._panel.querySelector('.grow-journal-ext__view');
    if (btn) {
      btn.querySelector('.grow-journal-ext__icon').textContent = preview ? 'code' : 'visibility';
      btn.setAttribute('aria-label', preview ? 'Edit (code)' : 'Preview');
      btn.setAttribute('title', preview ? 'Edit' : 'Preview');
      btn.setAttribute('aria-pressed', String(preview));
    }
    if (!preview) this._textarea.focus({ preventScroll: true });
  }

  // ---- instructions ("how to use your notes") -----------------------------
  // The guide is INJECTED into the notebook text, right after the "# course"
  // heading, while it is on, and stripped out again when closed — leaving a
  // pristine notebook of just the lesson structure. The injected block is
  // bracketed by HTML-comment markers, so this._text stays the pristine notes
  // (stripped on every input and before every save) and the markers never
  // render in the preview.

  _buildInstructionBlock() {
    return `${INSTR_START}\n${this.instructionsMarkdown}\n${INSTR_END}`;
  }

  _stripInstructions(text) {
    const re = new RegExp(`\\n*${escapeRegExp(INSTR_START)}[\\s\\S]*?${escapeRegExp(INSTR_END)}\\n*`, 'g');
    return String(text ?? '').replace(re, '\n\n').replace(/\n{3,}/g, '\n\n').replace(/^\n+/, '');
  }

  _injectInstructions(text) {
    const pristine = this._stripInstructions(text);
    const block = this._buildInstructionBlock();
    const lines = pristine.split('\n');
    const idx = lines.findIndex(l => /^#\s+\S/.test(l.trim())); // first level-1 heading
    if (idx === -1) return `${block}\n\n${pristine}`.replace(/\n{3,}/g, '\n\n').replace(/\s+$/, '');
    const before = lines.slice(0, idx + 1).join('\n');
    const after = lines.slice(idx + 1).join('\n').replace(/^\n+/, '');
    return `${before}\n\n${block}\n\n${after}`.replace(/\n{3,}/g, '\n\n').replace(/\s+$/, '');
  }

  // What the editor/preview currently shows: pristine notes, plus the injected
  // guide when it is on.
  _displayText() {
    return this._instructions ? this._injectInstructions(this._text) : this._text;
  }

  _refreshDisplay() {
    if (!this._panel) return;
    if (this._view === 'preview') {
      if (this._preview) this._preview.innerHTML = renderMarkdown(this._displayText());
    } else if (this._textarea) {
      this._textarea.value = this._displayText();
    }
  }

  toggleInstructions() {
    if (this._instructions) this.hideInstructions();
    else this.showInstructions();
  }

  showInstructions() {
    this._instructions = true;
    // Needs the body, so a collapsed float card expands first.
    if (this._dock === 'float' && this._collapsed) {
      this._collapsed = false;
      try { window.localStorage.setItem(LS_COLLAPSED, '0'); } catch (e) { /* ignore */ }
      this._applyDock();
    }
    this._applyInstructions();
    this._refreshDisplay();
    // Reveal the start of the injected guide.
    if (this._view === 'code' && this._textarea) {
      this._textarea.focus({ preventScroll: true });
      this._textarea.setSelectionRange(0, 0);
      this._textarea.scrollTop = 0;
    } else if (this._preview) {
      this._preview.scrollTop = 0;
    }
  }

  hideInstructions() {
    this._instructions = false;
    this._applyInstructions();
    this._refreshDisplay();  // textarea/preview back to pristine notes
    this._save();            // persist the pristine notebook
    if (this._view === 'code') this._textarea?.focus?.({ preventScroll: true });
  }

  _applyInstructions() {
    const p = this._panel;
    if (!p) return;
    const on = this._instructions;
    p.classList.toggle('is-instructions', on);
    const bar = p.querySelector('.grow-journal-ext__instructions-bar');
    if (bar) bar.hidden = !on;
    const helpBtn = p.querySelector('.grow-journal-ext__help');
    if (helpBtn) helpBtn.setAttribute('aria-pressed', String(on));
  }

  // ---- dock + float-card collapse -----------------------------------------

  setDock(dock) {
    if (!DOCK_IDS.includes(dock)) return;
    this._dock = dock;
    if (dock === 'float') this._collapsed = false; // open expanded when first floated
    try { window.localStorage.setItem(LS_DOCK, dock); } catch (e) { /* ignore */ }
    this._applyDock();
    this._scrollToHeading(this._headingFor(this._lastModel));
  }

  _applyDock() {
    if (!this._panel) return;
    this._panel.dataset.dock = this._dock;
    const isFloat = this._dock === 'float';
    this._panel.classList.toggle('is-collapsed', isFloat && this._collapsed);
    const collapseBtn = this._panel.querySelector('.grow-journal-ext__collapse');
    if (collapseBtn) {
      // NB: use display, not the `hidden` attribute — the button's own
      // `display:inline-flex` rule would override `[hidden]` and leave it
      // visible-but-inert in the edge docks (the "minimise does nothing" bug).
      collapseBtn.style.display = isFloat ? '' : 'none';
      collapseBtn.setAttribute('aria-expanded', String(!this._collapsed));
      collapseBtn.querySelector('.grow-journal-ext__icon').textContent = this._collapsed ? 'expand_more' : 'expand_less';
    }
    this._panel.querySelectorAll('.grow-journal-ext__dock').forEach(b =>
      b.setAttribute('aria-pressed', String(b.dataset.dock === this._dock)));
    this._applyFloatRect(isFloat);
  }

  // ---- float-card drag + resize -------------------------------------------

  _loadFloatRect() {
    if (this._floatRect) return this._floatRect;
    try {
      const raw = window.localStorage.getItem(LS_FLOATRECT);
      const r = raw && JSON.parse(raw);
      if (r && typeof r.l === 'number' && typeof r.t === 'number') this._floatRect = r;
    } catch (e) { /* ignore */ }
    return this._floatRect;
  }

  _saveFloatRect() {
    try { window.localStorage.setItem(LS_FLOATRECT, JSON.stringify(this._floatRect)); } catch (e) { /* ignore */ }
  }

  /**
   * In float mode, apply the persisted position/size as inline styles (so the
   * drag + native resize have something concrete to move) and clear them again
   * for the edge docks so their CSS insets take over.
   */
  _applyFloatRect(isFloat) {
    const p = this._panel;
    if (!p) return;
    const s = p.style;
    if (!isFloat) {
      this._applyingRect = true;
      s.left = s.top = s.width = s.height = s.insetInlineStart = s.insetBlockStart = '';
      this._applyingRect = false;
      return;
    }
    const r = this._loadFloatRect();
    if (!r) return; // no saved rect yet — let the CSS defaults place the card
    this._applyingRect = true;
    const maxL = Math.max(0, window.innerWidth - FLOAT_MIN_W);
    const maxT = Math.max(0, window.innerHeight - FLOAT_MIN_H);
    s.insetInlineStart = 'auto';
    s.insetBlockStart = 'auto';
    s.left = `${Math.min(Math.max(0, r.l), maxL)}px`;
    s.top = `${Math.min(Math.max(0, r.t), maxT)}px`;
    if (r.w) s.width = `${Math.max(FLOAT_MIN_W, r.w)}px`;
    if (r.h) s.height = `${Math.max(FLOAT_MIN_H, r.h)}px`;
    this._applyingRect = false;
  }

  _onDragStart(e) {
    // Only the float card drags, only with the primary button, and never when
    // grabbing a control in the header.
    if (this._dock !== 'float' || this._collapsed) return;
    if (e.button !== 0 || e.target.closest('button')) return;
    const rect = this._panel.getBoundingClientRect();
    this._drag = { dx: e.clientX - rect.left, dy: e.clientY - rect.top };
    this._panel.classList.add('is-dragging');
    try { this._head.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
    this._head.addEventListener('pointermove', this._onDragMove);
    this._head.addEventListener('pointerup', this._onDragEnd);
    this._head.addEventListener('pointercancel', this._onDragEnd);
    e.preventDefault();
  }

  _onDragMove(e) {
    if (!this._drag || !this._panel) return;
    const w = this._panel.offsetWidth;
    const h = this._panel.offsetHeight;
    const l = Math.min(Math.max(0, e.clientX - this._drag.dx), Math.max(0, window.innerWidth - w));
    const t = Math.min(Math.max(0, e.clientY - this._drag.dy), Math.max(0, window.innerHeight - h));
    const s = this._panel.style;
    s.insetInlineStart = 'auto';
    s.insetBlockStart = 'auto';
    s.left = `${l}px`;
    s.top = `${t}px`;
  }

  _onDragEnd() {
    if (!this._drag) return;
    this._endDrag();
    this._persistRectFromPanel();
  }

  _endDrag() {
    this._drag = null;
    if (!this._head) return;
    this._head.removeEventListener('pointermove', this._onDragMove);
    this._head.removeEventListener('pointerup', this._onDragEnd);
    this._head.removeEventListener('pointercancel', this._onDragEnd);
    this._panel?.classList.remove('is-dragging');
  }

  // Native CSS resize (bottom-right grip) reports through the ResizeObserver.
  _onResized() {
    if (this._applyingRect || this._dock !== 'float' || this._collapsed) return;
    this._persistRectFromPanel();
  }

  _persistRectFromPanel() {
    const p = this._panel;
    if (!p) return;
    const rect = p.getBoundingClientRect();
    this._floatRect = { l: Math.round(rect.left), t: Math.round(rect.top), w: Math.round(rect.width), h: Math.round(rect.height) };
    this._saveFloatRect();
  }

  toggleCollapse() {
    this._collapsed = !this._collapsed;
    try { window.localStorage.setItem(LS_COLLAPSED, this._collapsed ? '1' : '0'); } catch (e) { /* ignore */ }
    this._applyDock();
  }

  // ---- land on the current page's heading ----------------------------------

  _scrollToHeading(label) {
    if (!this._panel) return;
    if (this._view === 'preview') return this._scrollPreviewToHeading(label);
    this._scrollTextareaToHeading(label);
  }

  _scrollTextareaToHeading(label) {
    const ta = this._textarea;
    if (!ta || ta.hidden) return;
    const reset = () => { ta.focus({ preventScroll: true }); ta.setSelectionRange(0, 0); ta.scrollTop = 0; };
    if (!label) return reset();

    const src = ta.value; // the displayed text (may include the injected guide)
    const target = normalise(label);
    const lines = src.split('\n');
    let idx = -1;
    for (let i = 0; i < lines.length; i++) {
      if (isHeadingLine(lines[i]) && normalise(headingText(lines[i])) === target) { idx = i; break; }
    }
    if (idx === -1) return reset();

    let caret = 0;
    for (let i = 0; i <= idx; i++) caret += lines[i].length + 1; // +1 for '\n'
    caret = Math.min(caret, src.length);

    const lineHeight = parseFloat(window.getComputedStyle(ta).lineHeight) || 28;
    ta.focus({ preventScroll: true });
    ta.setSelectionRange(caret, caret);
    ta.scrollTop = Math.max(0, (idx - 1) * lineHeight);
  }

  _scrollPreviewToHeading(label) {
    const pv = this._preview;
    if (!pv || pv.hidden) return;
    if (!label) { pv.scrollTop = 0; return; }
    const target = normalise(label);
    const heads = pv.querySelectorAll('h1, h2, h3, h4, h5, h6');
    for (const el of heads) {
      if (normalise(el.textContent) === target) {
        pv.scrollTop = Math.max(0, el.offsetTop - 8);
        return;
      }
    }
    pv.scrollTop = 0;
  }

}

const growJournalExtension = new GrowJournalExtension();
Adapt.growJournal = growJournalExtension;

export default growJournalExtension;
